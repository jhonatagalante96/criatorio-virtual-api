
(()=>{
 const root=document.querySelector('.cover'); if(!root) return;
 const $=s=>root.querySelector(s);
 const defaults=JSON.parse(root.dataset.defaults||'{}');
 const allowed=JSON.parse(root.dataset.allowed||'[]');
 const qs=new URLSearchParams(location.search);
 const fromQuery={}; for(const key of allowed){ if(qs.has(key)) fromQuery[key]=qs.get(key); }
 const bool=v=>v===true||v==='true'||v==='1';
 function sanitizeColor(v,fallback){return /^#[0-9a-fA-F]{6}$/.test(v||'')?v:fallback}
 function initials(name){return (name||'CV').split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase()}
 function apply(input={}){
   const cfg={...defaults,...fromQuery,...input};
   cfg.name=String(cfg.name||defaults.name||'Criatório').slice(0,80);
   cfg.tagline=String(cfg.tagline??defaults.tagline??'').slice(0,120);
   cfg.badgeText=String(cfg.badgeText??defaults.badgeText??'').slice(0,32);
   cfg.showLogo=bool(cfg.showLogo); cfg.showBadge=bool(cfg.showBadge);
   cfg.accentColor=sanitizeColor(cfg.accentColor,defaults.accentColor);
   root.style.setProperty('--accent',cfg.accentColor);
   $('.cover__name').textContent=cfg.name;
   $('.cover__tagline').textContent=cfg.tagline;
   const logo=$('.cover__logo'); logo.hidden=!cfg.showLogo;
   if(cfg.showLogo){
      logo.innerHTML='';
      if(cfg.logoUrl){const img=new Image();img.alt='';img.src=cfg.logoUrl;logo.appendChild(img)}
      else logo.textContent=initials(cfg.name);
   }
   const badge=$('.cover__badge'); badge.hidden=!(cfg.showBadge&&cfg.badgeText); badge.textContent=cfg.badgeText;
   root.classList.toggle('compact',cfg.name.length>32); root.classList.toggle('compact2',cfg.name.length>52);
   window.__CURRENT_COVER_CONFIG__=cfg; return cfg;
 }
 window.setCoverConfig=apply;
 window.__COVER_READY__=false;
 const bootstrap=window.__COVER_CONFIG__||{};
 apply(bootstrap);
 const imgs=[...document.images];
 Promise.all(imgs.map(i=>i.complete?Promise.resolve():new Promise(r=>{i.onload=i.onerror=r}))).then(()=>{window.__COVER_READY__=true;document.documentElement.dataset.ready='true'});
})();
