# Criatório Virtual — Templates de Capa V0

Pacote de referência do V0-148 para implementação no backend V0-149 e consumo no frontend V0-150.

## Contrato visual
- Canvas canônico: **1920×640 (3:1)**.
- Área segura: **60% central** (x=20%..80%, y=14%..86%).
- 8 modelos versionados em `manifest.json`.
- O nome é sempre texto dinâmico; nunca deve ser rasterizado no asset-base.
- O background incluído neste pacote é referência visual. O painel central deliberadamente mascara o texto presente nas artes conceituais e garante que o conteúdo dinâmico seja a camada autoritativa.

## Configuração
`name` (obrigatório), `tagline`, `showLogo`, `logoUrl`, `accentColor`; `showBadge` e `badgeText` apenas nos modelos que os declaram. Veja `schema/config.schema.json`. Parâmetros não declarados pelo modelo devem ser rejeitados no backend.

## Runtime
Cada HTML:
- aceita query string para desenvolvimento;
- aceita `window.__COVER_CONFIG__` antes do carregamento;
- expõe `window.setCoverConfig(config)` para preview;
- marca `window.__COVER_READY__ = true` após carregar recursos;
- escreve conteúdo com `textContent` (sem HTML arbitrário).

## Renderer backend recomendado (.NET)
1. Resolver `modelId + version` pelo catálogo versionado.
2. Validar configuração pelo contrato do modelo e schema.
3. Abrir o HTML local com Playwright/Chromium em viewport 1920×640.
4. Injetar configuração somente com dados validados; bloquear requests de rede externa.
5. Esperar `window.__COVER_READY__ === true`.
6. Capturar `#cover` como PNG. Se desejado, converter para WebP com ImageSharp.
7. Persistir asset final + `modelId`, `version` e configuração efetiva.
8. Preview nunca altera a capa vigente; aplicação é operação separada.

### Segurança
- Não aceitar HTML/CSS livre do cliente.
- Não carregar fontes, imagens ou URLs remotas arbitrárias durante render.
- `logoUrl` em produção deve virar asset local/data URL resolvido pelo servidor.
- Sanitizar/validar cor e limites de texto também no backend.

## Exemplo
```json
{
  "modelId": "tropical_colorido",
  "version": 1,
  "config": {
    "name": "Criatório Vale Verde",
    "tagline": "Cuidado, cor e vida em cada canto",
    "showLogo": true,
    "logoAssetId": "asset_123",
    "accentColor": "#0B7A78"
  }
}
```

## Arquivos
- `manifest.json`: catálogo/versionamento/opções.
- `schema/config.schema.json`: schema geral da configuração.
- `templates/*/index.html`: templates.
- `shared/base.css` e `shared/runtime.js`: runtime determinístico.
- `assets/backgrounds`: artes-base.
- `preview/*.png`: snapshots de referência.
- `preview/index.html`: catálogo navegável.
