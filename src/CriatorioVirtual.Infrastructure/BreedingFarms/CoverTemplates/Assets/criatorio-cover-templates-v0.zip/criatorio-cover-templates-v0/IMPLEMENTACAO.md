# Nota de implementação dos templates

Os oito HTMLs usam apenas arquivos locais. O background incluído é a arte conceitual aprovada; como essas artes foram geradas inicialmente com texto demonstrativo, o template aplica um painel central opaco/blur que mascara o texto-base e torna a camada HTML dinâmica autoritativa.

Para produção, pode-se substituir os PNGs em `assets/backgrounds/` por versões finais sem texto mantendo os mesmos IDs e layouts. Isso não altera o contrato do renderer.

O runtime usa `textContent`, valida cor hexadecimal e limita comprimentos também no cliente. Essas validações não substituem a validação backend.
