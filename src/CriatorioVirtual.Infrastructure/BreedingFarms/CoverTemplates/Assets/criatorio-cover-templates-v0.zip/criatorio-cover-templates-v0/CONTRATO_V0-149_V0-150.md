# Contrato técnico V0-149 / V0-150 — Capa do Criatório

## Backend V0-149
### Endpoints propostos
- `GET /api/breeding-farms/{id}/cover` — capa vigente ou fallback.
- `PUT /api/breeding-farms/{id}/cover/upload` — multipart para imagem própria.
- `DELETE /api/breeding-farms/{id}/cover` — remove e restaura fallback.
- `GET /api/breeding-farm-cover-templates` — catálogo de modelos ativos.
- `POST /api/breeding-farm-cover-templates/{modelId}/preview` — gera preview temporário sem alterar a capa.
- `PUT /api/breeding-farms/{id}/cover/template` — renderiza e aplica explicitamente um modelo.

### Catálogo
Retornar `id`, `name`, `version`, `previewUrl`, `canvas`, `safeArea`, `supportedOptions` e `defaults`.

### Payload de aplicação
```json
{
  "modelId":"natureza_classica",
  "version":1,
  "config":{
    "name":"Criatório Vale Verde",
    "tagline":"Tradição e cuidado",
    "showLogo":true,
    "logoAssetId":"asset_123",
    "accentColor":"#48643A"
  }
}
```

### Persistência
Persistir `CoverAssetId`, `CoverOrigin` (`Upload|Template`), `CoverTemplateId`, `CoverTemplateVersion`, `CoverTemplateConfigJson` e `CoverUpdatedAt`. O asset final aplicado deve ser imutável; substituir cria novo asset/referência e segue a limpeza segura da infraestrutura vigente.

### Upload próprio
PNG/JPEG/WebP; máximo recomendado 8 MiB; mínimo 1200×400. Normalizar orientação e gerar derivado canônico 1920×640. V0 usa crop central equivalente a `object-fit: cover` / `object-position: center`.

### Renderer
Interface sugerida: `ICoverTemplateRenderer.RenderAsync(templateId, version, config, ct)`. Implementação V0: Playwright/Chromium headless com templates locais deste pacote, requests externos bloqueados e captura de `#cover` em 1920×640. PNG é o artefato canônico; WebP pode ser derivado via ImageSharp.

### Regras
- Owner ativo do tenant atual é o único que altera a capa.
- Rejeitar opção não declarada em `supportedOptions`.
- Nome obrigatório; demais campos seguem schema/limites do modelo.
- `logoAssetId` deve ser resolvido no servidor para asset local/data URL; nunca permitir URL externa arbitrária.
- Preview é sem efeito colateral; aplicar é uma operação separada.
- Mesmo `modelId + version + config + assets` deve produzir resultado determinístico.
- Modelo desativado não invalida capa já aplicada.

## Frontend V0-150
- Consumir catálogo da API; não manter catálogo paralelo.
- Gerar controles somente a partir de `supportedOptions`.
- Nome/tagline/logo/cor atualizam o preview; usar debounce de 300–500 ms se preview for remoto.
- Mostrar preview desktop 3:1 e janela mobile com a mesma capa usando crop central.
- Separar claramente `Visualizar` de `Aplicar`.
- Reutilizar o mesmo fluxo em Meu Criatório e onboarding; etapa do onboarding é opcional.
- Cobrir loading, erro/retry, upload inválido, modelo desativado entre preview/aplicação, remoção e retomada.
