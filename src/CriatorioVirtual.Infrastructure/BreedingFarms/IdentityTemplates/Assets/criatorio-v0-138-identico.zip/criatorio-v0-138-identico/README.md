# V0-138 — HTMLs fiéis aos modelos aprovados

Estratégia usada:
- cada HTML embute a própria arte aprovada em base64;
- sem parâmetros, a exibição fica idêntica ao modelo aprovado;
- quando parâmetros são informados, o arquivo cobre apenas as áreas de texto e reescreve o conteúdo.

## Arquivos
- premium.html
- natural.html
- imperial.html
- classico.html
- index.html

## Parâmetros suportados
### Premium
- name
- subtitle

### Natural
- name
- tagline
- subtitle

### Imperial
- name
- subtitle

### Clássico
- name
- subtitle

## Exemplos
- premium.html?name=GALANTE
- natural.html?name=GALANTE&tagline=LINHAGEM%20SELETA
- imperial.html?name=RENASCER&subtitle=DESDE%202026
- classico.html?name=CRIATÓRIO%20SOL

Também é possível passar window.__CRIATORIO_CONFIG__ antes do script, com os mesmos campos.

Observação:
para ficar idêntico visualmente, usei a própria arte aprovada como base. Se depois você quiser, eu posso fazer uma segunda etapa focada em decompor cada arte em peças menores para deixar a personalização ainda mais flexível.
